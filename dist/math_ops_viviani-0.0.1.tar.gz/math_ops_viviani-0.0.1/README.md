# math_operations

Description. 

The package math_operations is used to perform basic mathematical operations such as addition, subtraction, multiplication, division, and exponentiation.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install math_operations

```bash
pip install math_ops_viviani
```

## Author
Viviani Pedroso

## License
[MIT](https://choosealicense.com/licenses/mit/)